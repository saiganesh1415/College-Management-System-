package Model;

import java.util.Scanner;

public interface Operation {
	
	abstract void oper(Database database, Scanner scanner, int ID);

}
