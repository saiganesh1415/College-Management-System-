/**
 * 
 */
/**
 * @author Bichoy Emad
 *
 */
module UniversityManagementSystem {
	requires java.sql;
}